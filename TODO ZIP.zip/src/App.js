import { useState, useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { addTask, deleteTask, toggleTask, editTask, clearCompleted } from "./redux/actions";
import "./App.css";

function App() {
  const [task, setTask] = useState("");
  const [filter, setFilter] = useState("all"); 
  const [editId, setEditId] = useState(null); 
  const [editText, setEditText] = useState("");

  const tasks = useSelector((state) => state.tasks.tasks);
  const dispatch = useDispatch();

  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  const handleAddTask = () => {
    if (task.trim() === "") return;

    const newTask = {
      id: Date.now(),
      text: task,
      completed: false,
    };

    dispatch(addTask(newTask));
    setTask("");
  };

  const handleEditSave = (id) => {
    if (editText.trim() === "") return;
    dispatch(editTask({ id, text: editText }));
    setEditId(null);
    setEditText("");
  };

  const filteredTasks = tasks.filter((t) => {
    if (filter === "completed") return t.completed;
    if (filter === "pending") return !t.completed;
    return true;
  });

  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.completed).length;
  const remainingTasks = totalTasks - completedTasks;

 return (
  <div className="container">
    <h2>Todo App</h2>

    <div className="input-container">
      <input
        type="text"
        value={task}
        onChange={(e) => setTask(e.target.value)}
        placeholder="Add a task..."
      />
      <button className="add-btn" onClick={handleAddTask}>+</button>
    </div>

    <div className="counter">
      Total: {totalTasks} | Completed: {completedTasks} | Remaining: {remainingTasks}
    </div>

    <div className="filter-buttons">
      <button onClick={() => setFilter("all")}>All</button>
      <button onClick={() => setFilter("completed")}>Completed</button>
      <button onClick={() => setFilter("pending")}>Pending</button>
    </div>

    <button className="clear-btn" onClick={() => dispatch(clearCompleted())}>
      Clear Completed
    </button>

    {filteredTasks.map((t) => (
      <div className="task" key={t.id}>
        <div>
          <input
            type="checkbox"
            checked={t.completed}
            onChange={() => dispatch(toggleTask(t.id))}
          />

          {editId === t.id ? (
            <input
              type="text"
              value={editText}
              onChange={(e) => setEditText(e.target.value)}
              onBlur={() => handleEditSave(t.id)}
              onKeyDown={(e) => e.key === "Enter" && handleEditSave(t.id)}
              autoFocus
              style={{ marginLeft: "8px" }}
            />
          ) : (
            <span
              className={t.completed ? "completed" : ""}
              onDoubleClick={() => {
                setEditId(t.id);
                setEditText(t.text);
              }}
              style={{ marginLeft: "8px" }}
            >
              {t.text}
            </span>
          )}
        </div>

        <button className="delete-btn" onClick={() => dispatch(deleteTask(t.id))}>
          🗑️
        </button>
      </div>
    ))}

    {tasks.length === 0 && <p className="empty">No tasks yet 🎉</p>}
  </div>
);

export default App;